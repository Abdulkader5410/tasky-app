import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:u_learning_app/pages/signin/bloc/signin_bloc.dart';

class SiginController {
  BuildContext context;

  SiginController(this.context);

  void handleSignin(String type) {
    if (type == "email") {
      try {
        final state = context.read<SigninBloc>().state;

        final String email = state.email;
        final String password = state.password;

        if (email.isEmpty) {}
        if (password.isEmpty) {}
        try{

        }
        catch(e){}
      } catch (e) {}
    }
  }
}