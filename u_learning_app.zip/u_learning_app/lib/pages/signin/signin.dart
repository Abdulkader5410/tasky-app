import 'package:flutter/material.dart';
import 'package:u_learning_app/main.dart';

class Signin extends StatefulWidget {
  const Signin({super.key});

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  @override
  Widget build(BuildContext context) {
    mq = MediaQuery.of(context).size;

    return SafeArea(
        child: Scaffold(
      backgroundColor: white,
      body: SingleChildScrollView(
        child: Container(
          color: white,
          child: Column(
            children: [
              SizedBox(
                height: mq.height * 0.03,
              ),
              Text("Login", style: TextStyle(fontSize: 20, color: blue)),
              SizedBox(
                height: mq.height * 0.06,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                      onTap: () {},
                      child: Image.asset(
                        "assets/icons/ic_google.png",
                        width: 30,
                        height: 30,
                      )),
                  SizedBox(
                    width: mq.width * 0.07,
                  ),
                  InkWell(
                      onTap: () {},
                      child: Image.asset(
                        "assets/icons/ic_apple.png",
                        width: 35,
                        height: 35,
                      )),
                  SizedBox(
                    width: mq.width * 0.07,
                  ),
                  InkWell(
                      onTap: () {},
                      child: Image.asset(
                        "assets/icons/ic_facebook.png",
                        width: 35,
                        height: 35,
                      )),
                ],
              ),
              SizedBox(
                height: mq.height * 0.03,
              ),
              Text("Or use email account login",
                  style: TextStyle(fontSize: 14, color: blue)),
              SizedBox(
                height: mq.height * 0.03,
              ),
              Container(
                color: white,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Email", style: TextStyle(fontSize: 14, color: blue)),
                    SizedBox(
                      height: mq.height * 0.01,
                    ),
                    SizedBox(
                      height: mq.height * 0.08,
                      width: mq.width * 0.85,
                      child: TextFormField(
                          cursorColor: orange,
                          textAlign: TextAlign.start,
                          decoration: InputDecoration(
                              prefixIcon: Icon(Icons.person, color: blue),
                              hintText: "Email Address",
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: orange),
                                  borderRadius: BorderRadius.circular(12)),
                              hintStyle: const TextStyle(fontSize: 14),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: blue),
                                  borderRadius: BorderRadius.circular(12)))),
                    ),
                    SizedBox(
                      height: mq.height * 0.03,
                    ),
                    Text("Password",
                        style: TextStyle(fontSize: 14, color: blue)),
                    SizedBox(
                      height: mq.height * 0.01,
                    ),
                    SizedBox(
                      height: mq.height * 0.08,
                      width: mq.width * 0.85,
                      child: TextFormField(
                          cursorColor: orange,
                          obscureText: true,
                          textAlign: TextAlign.start,
                          decoration: InputDecoration(
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: orange),
                                  borderRadius: BorderRadius.circular(12)),
                              prefixIcon: Icon(Icons.password, color: blue),
                              hintText: "Password",
                              hintStyle: TextStyle(fontSize: 14, color: blue),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(color: blue),
                                  borderRadius: BorderRadius.circular(12)))),
                    ),
                    SizedBox(
                      height: mq.height * 0.03,
                    ),
                    Text("Forgot password",
                        style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontSize: 14,
                            color: blue)),
                  ],
                ),
              ),
              SizedBox(
                height: mq.height * 0.11,
              ),
              SizedBox(
                height: mq.height * 0.08,
                width: mq.width * 0.85,
                child: MaterialButton(
                  color: blue,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12))),
                  onPressed: () {},
                  child: Text("Log In",
                      style: TextStyle(fontSize: 14, color: white)),
                ),
              ),
              SizedBox(
                height: mq.height * 0.03,
              ),
              SizedBox(
                height: mq.height * 0.08,
                width: mq.width * 0.85,
                child: MaterialButton(
                  shape: OutlineInputBorder(
                      borderSide: BorderSide(color: blue),
                      borderRadius:
                          const BorderRadius.all(Radius.circular(12))),
                  onPressed: () {},
                  child: Text("Sign Up",
                      style: TextStyle(fontSize: 14, color: blue)),
                ),
              ),
            ],
          ),
        ),
      ),
    ));
  }
}
