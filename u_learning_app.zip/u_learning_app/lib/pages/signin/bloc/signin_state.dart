class SigninState {
  final String email, password;

  SigninState({this.email = "", this.password = ""});

  SigninState copyWith({String? email, String? password}) {
    return SigninState(
        email: email ?? this.email, password: password ?? this.password);
  }
}