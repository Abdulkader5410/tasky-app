import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:u_learning_app/pages/welcome/bloc/welcome_bloc.dart';
import 'package:u_learning_app/pages/welcome/bloc/welcome_event.dart';

import '../../main.dart';
import 'bloc/welcome_state.dart';

class Welcome extends StatefulWidget {
  const Welcome({super.key});

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  PageController pageController = PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    mq = MediaQuery.of(context).size;

    return Container(
      padding: const EdgeInsets.all(10),
      color: Colors.white,
      child: Scaffold(
        body: BlocBuilder<WelcomeBloc, WelcomeState>(
          builder: (context, state) {
            return Container(
              color: Colors.white,
              child: Column(
                children: [
                  SizedBox(
                    height: mq.height * 0.85,
                    child: PageView(
                      controller: pageController,
                      onPageChanged: (index) {
                        state.page = index;
                        BlocProvider.of<WelcomeBloc>(context)
                            .add(WelcomeEvent());
                      },
                      children: [
                        _pages(
                            1,
                            "First See Learning",
                            "Forget about a for of paper all knowledge in one learning",
                            "NEXT",
                            "assets/images/reading.jpg"),
                        _pages(
                            2,
                            "Connect With Everyone",
                            "Always kepp in touch with your tutor and friend , let's get connected !",
                            "NEXT",
                            "assets/images/relax.jpg"),
                        _pages(
                            3,
                            "Always Fascinated Learning",
                            "Anywhere , anytime . The time is at your discretion so study whenever you want",
                            "Get Started",
                            "assets/images/getStarted.jpg"),
                      ],
                    ),
                  ),
                  DotsIndicator(
                    position: state.page,
                    dotsCount: 3,
                    decorator: DotsDecorator(
                        activeColor: orange,
                        color: blue,
                        activeShape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        activeSize: const Size(16.0, 10.0)),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _pages(int index, String title, String subtitle, String nameBtn,
      String imagePath) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Image.asset(imagePath, width: mq.width * 1, height: mq.height * 0.5),
          const SizedBox(
            height: 0,
          ),
          Text(title, style: const TextStyle(fontSize: 20)),
          const SizedBox(
            height: 20,
          ),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14)),
          const SizedBox(
            height: 50,
          ),
          SizedBox(
            width: mq.width * 0.90,
            height: mq.height * 0.08,
            child: MaterialButton(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              color: blue,
              onPressed: () {
                if (index < 3) {
                  pageController.animateToPage(index,
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.linear);
                } else {
                  Navigator.pushNamedAndRemoveUntil(
                      context, "/signinPage", (route) => false);
                }
              },
              child: Text(nameBtn,
                  style:
                      TextStyle(fontSize: 16, color: white, letterSpacing: 2)),
            ),
          )
        ],
      ),
    );
  }
}
