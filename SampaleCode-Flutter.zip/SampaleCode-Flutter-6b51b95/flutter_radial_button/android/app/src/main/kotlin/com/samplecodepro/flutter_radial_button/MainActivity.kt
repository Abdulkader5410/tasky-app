package com.samplecodepro.flutter_radial_button

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
