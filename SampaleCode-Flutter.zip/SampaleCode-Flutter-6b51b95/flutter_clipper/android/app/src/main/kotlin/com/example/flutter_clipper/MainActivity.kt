package com.example.flutter_clipper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
