package com.example.image_to_text_conveter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
