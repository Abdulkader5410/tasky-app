package com.example.login_with_signup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
