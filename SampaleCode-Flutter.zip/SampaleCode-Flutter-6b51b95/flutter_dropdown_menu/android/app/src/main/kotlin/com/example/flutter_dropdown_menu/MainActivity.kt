package com.example.flutter_dropdown_menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
