package com.example.flutter_image_picker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
