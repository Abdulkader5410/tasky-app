package com.example.login_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
