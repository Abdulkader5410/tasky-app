package com.example.flutter_image_slider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
