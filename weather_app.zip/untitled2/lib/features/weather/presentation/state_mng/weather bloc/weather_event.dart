
import 'package:equatable/equatable.dart';
import 'package:geolocator/geolocator.dart';

sealed class WeatherEvent extends Equatable {
  const WeatherEvent();

  @override
  List<Object> get props => [];
}

class FeatchWeather extends WeatherEvent {
  // final Position pos;
  //
  // const FeatchWeather({required this.pos});

  @override
  List<Object> get props => [];
}

class SearchWeatherEvent extends WeatherEvent {
  final String city;

  const SearchWeatherEvent({required this.city});

  @override
  List<Object> get props => [city];
}
