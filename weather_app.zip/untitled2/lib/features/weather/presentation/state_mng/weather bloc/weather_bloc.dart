import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:untitled2/core/failure/failure.dart';
import 'package:untitled2/core/string/string_failure.dart';
import 'package:untitled2/features/weather/domain/usecase/featch_weather_usecase.dart';
import 'package:untitled2/features/weather/domain/usecase/search_weather_usecase.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_event.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_state.dart';

class WeatherBloc extends Bloc<WeatherEvent, WeatherState> {
  final FeatchWeathersUC featchWeathersUC;
  final SearchWeathersUC searchWeathersUC;

  WeatherBloc({required this.featchWeathersUC , required this.searchWeathersUC}) : super(WeatherInitial()) {
    on<WeatherEvent>((event, emit) async {
      if(event is FeatchWeather){
        emit(LoadingState());

        final weatherOrFailure = await featchWeathersUC(/*getCity(event.pos)*/
            "aleppo");


        weatherOrFailure.fold(
              (failure) {
            emit(FailureState());
          },
              (weather) {
            emit(SuccessState(weather: weather));
          },
        );
      }
      else if(event is SearchWeatherEvent){

        emit(LoadingState());

        final weatherOrFailure = await searchWeathersUC(/*getCity(event.pos)*/
             event.city);

        print(weatherOrFailure);

        weatherOrFailure.fold(
              (failure) {
            emit(FailureState());
          },
              (weather) {
            emit(SuccessState(weather: weather));
          },
        );
      }

    });
  }

  // Future<String> getCity(Position pos) async {
  //   List<Placemark> placeMarks = await placemarkFromCoordinates(
  //       pos.latitude, pos.longitude);
  //   return placeMarks.first.locality!;
  // }

  String _mapFailureType(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return SERVER_FAILURE_MESSAGE;
      case OfflineFailure:
        return SERVER_FAILURE_MESSAGE;

      default:
        return "Unexpcted Error";
    }
  }
}
