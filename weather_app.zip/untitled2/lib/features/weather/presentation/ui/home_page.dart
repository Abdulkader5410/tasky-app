import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_bloc.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_event.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_state.dart';
import 'package:untitled2/features/weather/presentation/ui/details_page.dart';
import 'package:untitled2/features/weather/presentation/ui/widgets/custom_row.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();
  GlobalKey<FormState> formState = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black87,
      extendBodyBehindAppBar: true,
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0,
      //   systemOverlayStyle:
      //       const SystemUiOverlayStyle(statusBarBrightness: Brightness.dark),
      // ),
      body: BlocBuilder<WeatherBloc, WeatherState>(
        builder: (context, state) {
          if (state is SuccessState) {
            return SingleChildScrollView(
              child: Container(
                decoration: const BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.purple, Colors.black])),
                child: Padding(
                  padding: const EdgeInsets.only(left: 12, right: 12, top: 30),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Form(
                        key: formState,
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            SizedBox(
                              width: 60,
                              height: 60,
                              child: MaterialButton(
                                  onPressed: () {
                                    _searchWeather(context,
                                        _searchController.text.toString()
                                            .trim());
                                  },
                                  child: const Icon(Icons.search)),
                            ),
                            SizedBox(
                              width: MediaQuery
                                  .sizeOf(context)
                                  .width / 2,
                              height: 60,
                              child: Center(
                                child: TextFormField(
                                  decoration: const InputDecoration(

                                      hintText: "Search on city"),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                      , const SizedBox(height: 15),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            "  ${state.weather.country!}, ",
                            style: const TextStyle(
                                fontSize: 18, color: Colors.white),
                          ),
                          Text(
                            state.weather.name!,
                            style: const TextStyle(
                                fontSize: 18, color: Colors.white),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Center(
                        child: _getIcon(state.weather.id!, 120, 120),
                      ),
                      const SizedBox(height: 10),
                      Center(
                        child: Text(
                          "${(state.weather.temperature! - 273.15)
                              .round()}\u00B0C",
                          style: const TextStyle(
                              fontSize: 34,
                              fontWeight: FontWeight.w600,
                              color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Center(
                        child: Text(
                          state.weather.main!,
                          style: const TextStyle(
                              fontSize: 24, color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Center(
                        child: Text(
                          // "${DateFormat().add_MMMd().format(state.weather.!)} ,${DateFormat().add_EEEE().format(state.weather.dt!)}   ${DateFormat().add_jm().format(state.weather.dt!)}  ",
                          "",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          CustomRow(
                              imageName: "assets/images/sunny.png",
                              w: 50,
                              h: 50,
                              text1: "Sunrise",
                              text2: DateFormat.jm()
                                  .format(state.weather.sunrise!)),
                          CustomRow(
                              imageName: "assets/images/termo_max.png",
                              w: 50,
                              h: 50,
                              text1: "Termo Max",
                              text2:
                              "${(state.weather.termoMax! - 273.15)
                                  .round()} \u00B0C")
                        ],
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          CustomRow(
                              imageName: "assets/images/moon.png",
                              w: 50,
                              h: 50,
                              text1: "Sunset",
                              text2: DateFormat.jm()
                                  .format(state.weather.sunset!)),
                          CustomRow(
                              imageName: "assets/images/termo_min.png",
                              w: 50,
                              h: 50,
                              text1: "Termo Min",
                              text2:
                              "${(state.weather.termoMin! - 273.15)
                                  .round()} \u00B0C")
                        ],
                      ),
                      const SizedBox(height: 25),
                      MaterialButton(
                        color: Colors.black12,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      DetailsPage(weather: state.weather)));
                        },
                        child: const Text(
                          "more  >>",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          } else if (state is FailureState) {
            print("City not found");
            return Container(
              color: Colors.red,
            );
          } else {
            return Container(
              color: Colors.blue,
            );
          }
        },
      ),
    );
  }

  Future<void> _searchWeather(BuildContext context, String city) async {
    BlocProvider.of<WeatherBloc>(context).add(SearchWeatherEvent(city: city));
  }

  Widget _getIcon(int code, double width, double height) {
    switch (code) {
      case >= 200 && < 300: //lightnghit
        return Image.asset(
          "assets/images/lightnghit.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case >= 300 && < 400: //drizzle
        return Image.asset(
          "assets/images/drizzle.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case >= 500 && < 600: //rain
        return Image.asset(
          "assets/images/rain.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case >= 600 && < 700: //snow
        return Image.asset(
          "assets/images/snow.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case >= 700 && < 800: //misty
        return Image.asset(
          "assets/images/misty.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case == 800: //clear sky
        return Image.asset(
          "assets/images/sunny.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
      case > 800 && <= 804: //clouds
        return Image.asset(
          "assets/images/cloud.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );

      default:
        return Image.asset(
          "assets/images/cloudy.png",
          width: width,
          height: height,
          fit: BoxFit.fill,
        );
    }
  }
}


//
// TextFormField(
// controller: tf_name_controller,
// validator: (value) {
// if (value!.length > 100) {
// return "Full Name can't to be larger than 150 letter";
// }
// if (value.length < 2) {
// return "Full Name can't to be less than 2 letter";
// }
// return null;
// },
// textAlign: TextAlign.left,
// textAlignVertical: TextAlignVertical.bottom,
// cursorColor: prupleColor,
// style: const TextStyle(
// color: prupleColor,
// fontSize: 18,
// fontWeight: FontWeight.w300),
// decoration: InputDecoration(
// focusedBorder: OutlineInputBorder(
// borderRadius: BorderRadius.circular(60),
// borderSide:
// const BorderSide(color: prupleColor)),
// prefixIcon:
// const Icon(Icons.person, color: prupleColor),
// hintText: "Enter Full Name",
// border: OutlineInputBorder(
// borderRadius: BorderRadius.circular(60)))),
