import 'package:flutter/material.dart';

class CustomRow extends StatelessWidget {
  final String imageName , text1 , text2;
  final double w , h;


  const CustomRow(
      {super.key,
      required this.imageName,
      required this.w,
      required this.h,
      required this.text1,
      required this.text2});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Image.asset(
          imageName,
          // "assets/images/icons8-snow-96.png",
          width: w,
          height: h,
        ),
        const SizedBox(
          width: 10,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              // "Termo Max",
              text1,
              style: const TextStyle(fontSize: 14, color: Colors.white),
            ),
            Text(
              text2,
              // "${(state.weather.termoMax! - 273.15).round()} \u00B0C",
              style: const TextStyle(fontSize: 12, color: Colors.white),
            )
          ],
        )
      ],
    );
  }
}
