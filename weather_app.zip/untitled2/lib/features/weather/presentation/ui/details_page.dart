import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled2/features/weather/domain/entity/weather_entity.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_bloc.dart';
import 'package:untitled2/features/weather/presentation/state_mng/weather%20bloc/weather_state.dart';
import 'package:untitled2/features/weather/presentation/ui/home_page.dart';
import 'package:untitled2/features/weather/presentation/ui/widgets/custom_row.dart';
import 'package:weather/weather.dart';

class DetailsPage extends StatefulWidget {
  final WeatherEntity weather;

  const DetailsPage({super.key, required this.weather});

  @override
  State<DetailsPage> createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.purple, Colors.black])),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                MaterialButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const CircleAvatar(
                      backgroundColor: Colors.white30,
                      child: Icon(
                          color: Colors.white,
                          size: 30,
                          Icons.arrow_back_sharp),
                    )),
                Center(
                  child: SizedBox(
                    width: MediaQuery.sizeOf(context).width / 1.05,
                    height: MediaQuery.sizeOf(context).height / 1.2,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          textAlign: TextAlign.center,
                          "Weather Description\n${widget.weather.description.toString()}",
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16),
                        ),
                        const SizedBox(
                          height: 80,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                CustomRow(
                                    imageName: "assets/images/wind.png",
                                    w: 50,
                                    h: 50,
                                    text1: "Wind Speed",
                                    text2:
                                        "${widget.weather.windSpeed.toString()} km/h"),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                CustomRow(
                                    imageName: "assets/images/humidity.png",
                                    w: 50,
                                    h: 50,
                                    text1: "Humidity",
                                    text2:
                                        "${widget.weather.humidity.toString()} %"),
                              ],
                            ),
                          ],
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                CustomRow(
                                    imageName: "assets/images/pressure.png",
                                    w: 50,
                                    h: 50,
                                    text1: "Pressure",
                                    text2:
                                        "${widget.weather.pressure.toString()} hPa"),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                CustomRow(
                                    imageName: "assets/images/sea.png",
                                    w: 50,
                                    h: 50,
                                    text1: "Sea High",
                                    text2:
                                        "${widget.weather.seaLevel.toString()} m"),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )));
  }
}
