import 'package:dartz/dartz.dart';
import 'package:untitled2/core/failure/failure.dart';
import 'package:untitled2/features/weather/domain/dom_repo/dom_repo.dart';
import 'package:untitled2/features/weather/domain/entity/weather_entity.dart';

class FeatchWeathersUC {
  late final DomRepo weatherDomRepo;

  FeatchWeathersUC(this.weatherDomRepo);

  Future<Either<Failure, WeatherEntity>> call(String city) async{
    return await weatherDomRepo.featchWeather(city);
  }

}
