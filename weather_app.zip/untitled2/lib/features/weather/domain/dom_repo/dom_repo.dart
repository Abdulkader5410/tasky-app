import 'package:dartz/dartz.dart';
import 'package:untitled2/core/failure/failure.dart';
import 'package:untitled2/features/weather/domain/entity/weather_entity.dart';


abstract class DomRepo {
  Future<Either<Failure, WeatherEntity>> featchWeather(String city);
  Future<Either<Failure, WeatherEntity>> searchFeatchWeather(String city);
}