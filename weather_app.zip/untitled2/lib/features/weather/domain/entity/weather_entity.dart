// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

class WeatherEntity extends Equatable {
  String? country, name, main, description;
  var temperature, termoMin, termoMax, windSpeed;
  DateTime? sunrise, sunset;

  var humidity, pressure, seaLevel, id;

  WeatherEntity(
      {required this.country,
      required this.name,
      required this.main,
      required this.temperature,
      required this.termoMax,
      required this.termoMin,
      required this.description,
      required this.sunrise,
      required this.sunset,
      required this.windSpeed,
      required this.pressure,
      required this.humidity,
      required this.seaLevel,
      required this.id});

  @override
  List<Object?> get props => [
        name,
        country,
        main,
        description,
        temperature,
        termoMax,
        termoMin,
        sunrise,
        sunset,
        windSpeed,
        seaLevel,
        pressure,
        humidity,
    id
      ];
}
