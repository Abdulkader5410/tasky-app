import 'package:dartz/dartz.dart';
import 'package:untitled2/core/exception/exception.dart';
import 'package:untitled2/core/failure/failure.dart';
import 'package:untitled2/core/network/network.dart';
import 'package:untitled2/features/weather/data/data_sources/remote_data_source.dart';
import 'package:untitled2/features/weather/data/model/weather_model.dart';
import 'package:untitled2/features/weather/domain/dom_repo/dom_repo.dart';
import 'package:untitled2/features/weather/domain/entity/weather_entity.dart';


class WeatherDataRepo extends DomRepo {
  final RemoteDataSource remoteDataSource;
  final Networkinfo networkinfo;

  WeatherDataRepo({required this.networkinfo, required this.remoteDataSource});

  @override
  Future<Either<Failure, WeatherEntity>> featchWeather(String city) async {
    if (await networkinfo.isConnected) {
      try {
        final weather = await remoteDataSource.featchWeather(city);
        return Right(weather);
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      throw OfflineException();
    }
  }

  @override
  Future<Either<Failure, WeatherEntity>> searchFeatchWeather(String city) async{
    if (await networkinfo.isConnected) {
      try {
        final weather = await remoteDataSource.featchWeather(city);
        return Right(weather);
      } on ServerException {
        return Left(ServerFailure());
      }
    } else {
      throw OfflineException();
    }
  }


}
