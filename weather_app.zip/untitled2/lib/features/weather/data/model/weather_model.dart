// ignore_for_file: must_be_immutable

import 'package:untitled2/features/weather/domain/entity/weather_entity.dart';

class WeatherModel extends WeatherEntity {
  WeatherModel(
      {String? country,
      name,
      main,
      description,
      var temperature,
      termoMin,
      termoMax,
      sunrise,
      sunset,
      windSpeed,
      var pressure,
      humidity,
      seaLevel,
      id
      // int? id
      })
      : super(
            country: country,
            main: main,
            name: name,
            description: description,
            seaLevel: seaLevel,
            humidity: humidity,
            pressure: pressure,
            windSpeed: windSpeed,
            sunrise: sunrise,
            sunset: sunset,
            temperature: temperature,
            termoMax: termoMax,
            termoMin: termoMin,
            id: id);

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    return WeatherModel(
        country: json['sys']['country'],
        name: json['name'],
        humidity: json['main']['humidity'],
        pressure: json['main']['pressure'],
        seaLevel: json['main']['sea_level'],
        sunrise:
            DateTime.fromMillisecondsSinceEpoch(json['sys']['sunrise'] * 1000),
        sunset:
            DateTime.fromMillisecondsSinceEpoch(json['sys']['sunset'] * 1000),
        main: json['weather'][0]['main'],
        id: json['weather'][0]['id'],
        description: json['weather'][0]['description'],
        windSpeed: json['wind']['speed'],
        termoMax: json['main']['temp_max'],
        temperature: json['main']['temp'],
        termoMin: json['main']['temp_min']);
  }

  Map<String, dynamic> toJson() {
    return {
      'country ': country,
      'name': name,
      'description': description,
      'humidity': humidity,
      'sunrise': sunrise,
      'sunset': sunset,
      // 'id': id,
      'main': main,
      'speed': windSpeed,
      'pressure': pressure,
      'sea_level': seaLevel,
      'temp_min': termoMin,
      'temp_max': termoMax,
      'temperature': temperature,
      'id': id
    };
  }
}
