class ServerException implements Exception {}

class OfflineException implements Exception {}


