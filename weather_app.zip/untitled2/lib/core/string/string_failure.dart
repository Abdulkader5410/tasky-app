String SERVER_FAILURE_MESSAGE = "please try again later !";
String OFFLINE_FAILURE_MESSAGE = "please check your internet connection !";