import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled2/core/network/network.dart';
import 'package:untitled2/features/weather/data/data_repo/data_repo.dart';
import 'package:untitled2/features/weather/data/data_sources/remote_data_source.dart';
import 'package:untitled2/features/weather/domain/dom_repo/dom_repo.dart';
import 'package:untitled2/features/weather/domain/usecase/featch_weather_usecase.dart';
import 'package:untitled2/features/weather/domain/usecase/search_weather_usecase.dart';

import 'features/weather/presentation/state_mng/weather bloc/weather_bloc.dart';

final sl = GetIt.instance;

Future<void> initS() async {
  //// features - posts

  // bloc

  sl.registerFactory(() => WeatherBloc(featchWeathersUC: sl() , searchWeathersUC: sl()));

  //usecase

  sl.registerLazySingleton(() => FeatchWeathersUC(sl()));
  sl.registerLazySingleton(() => SearchWeathersUC(sl()));

  //repo

  sl.registerLazySingleton<DomRepo>(
          () => WeatherDataRepo(networkinfo: sl(), remoteDataSource: sl()) );

  //datasource

  sl.registerLazySingleton<RemoteDataSource>(
          () => RemoteDataSourceImpl(client: sl()));

  //// core

  sl.registerLazySingleton<Networkinfo>(() => NetworkinfoImpl(netCheck: sl()));

  //// external

  SharedPreferences sp = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sp);

  sl.registerLazySingleton(() => InternetConnectionChecker());

  sl.registerLazySingleton(() => http.Client());
}
