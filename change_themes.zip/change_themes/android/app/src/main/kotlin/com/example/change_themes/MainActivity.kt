package com.example.change_themes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
