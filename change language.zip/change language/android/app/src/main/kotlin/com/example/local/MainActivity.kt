package com.example.local

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
